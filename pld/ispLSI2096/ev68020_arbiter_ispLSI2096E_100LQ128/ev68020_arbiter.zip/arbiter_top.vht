-- VHDL test bench created from symbol arbiter_top.sym -- Nov 10 20:59:56 2024

LIBRARY vanmacro;
USE vanmacro.components.ALL;
LIBRARY ieee;
LIBRARY generics;
USE ieee.std_logic_1164.ALL;
USE ieee.numeric_std.ALL;
USE generics.components.ALL;

entity testbench is
end testbench;

Architecture behavior of testbench is

   signal   INV_RD : std_logic;
   signal      R_W : std_logic;
   signal   INV_WR : std_logic;
   signal   INV_DS : std_logic;
   signal     SIZ1 : std_logic;
   signal     SIZ0 : std_logic;
   signal       A1 : std_logic;
   signal  INV_WRL : std_logic;
   signal       A0 : std_logic;
   signal  INV_WRU : std_logic;
   signal INV_WRLL : std_logic;
   signal INV_WRLM : std_logic;
   signal INV_WRUM : std_logic;
   signal INV_WRUU : std_logic;
   signal   PLDCLK : std_logic;
   signal INV_MPU_DSACK1 : std_logic;
   signal   INV_AS : std_logic;
   signal INV_SEL_1 : std_logic;
   signal INV_MPU_DSACK0 : std_logic;
   signal    WAIT1 : std_logic;
   signal INV_SEL_8toB : std_logic;
   signal INV_SEL_4to7 : std_logic;
   signal    WAIT2 : std_logic;
   signal INV_SEL_C : std_logic;
   signal INV_SEL_0 : std_logic;
   signal INV_SEL_F : std_logic;
   signal INV_IACK_AVEC : std_logic;
   signal  INV_FC2 : std_logic;
   signal  INV_FC1 : std_logic;
   signal  INV_FC0 : std_logic;
   signal  INV_CPU : std_logic;

   component ARBITER_TOP
      Port (  INV_RD : Out   std_logic;
                 R_W : In    std_logic;
              INV_WR : Out   std_logic;
              INV_DS : In    std_logic;
                SIZ1 : In    std_logic;
                SIZ0 : In    std_logic;
                  A1 : In    std_logic;
             INV_WRL : Out   std_logic;
                  A0 : In    std_logic;
             INV_WRU : Out   std_logic;
             INV_WRLL : Out   std_logic;
             INV_WRLM : Out   std_logic;
             INV_WRUM : Out   std_logic;
             INV_WRUU : Out   std_logic;
              PLDCLK : In    std_logic;
             INV_MPU_DSACK1 : Out   std_logic;
              INV_AS : In    std_logic;
             INV_SEL_1 : In    std_logic;
             INV_MPU_DSACK0 : Out   std_logic;
               WAIT1 : In    std_logic;
             INV_SEL_8toB : In    std_logic;
             INV_SEL_4to7 : In    std_logic;
               WAIT2 : In    std_logic;
             INV_SEL_C : In    std_logic;
             INV_SEL_0 : In    std_logic;
             INV_SEL_F : In    std_logic;
             INV_IACK_AVEC : Out   std_logic;
             INV_FC2 : In    std_logic;
             INV_FC1 : In    std_logic;
             INV_FC0 : In    std_logic;
             INV_CPU : Out   std_logic );
   end component;

begin
   UUT : ARBITER_TOP
      Port Map ( A0=>A0, A1=>A1, INV_AS=>INV_AS, INV_CPU=>INV_CPU,
                 INV_DS=>INV_DS, INV_FC0=>INV_FC0, INV_FC1=>INV_FC1,
                 INV_FC2=>INV_FC2, INV_IACK_AVEC=>INV_IACK_AVEC,
                 INV_MPU_DSACK0=>INV_MPU_DSACK0,
                 INV_MPU_DSACK1=>INV_MPU_DSACK1, INV_RD=>INV_RD,
                 INV_SEL_0=>INV_SEL_0, INV_SEL_1=>INV_SEL_1,
                 INV_SEL_4to7=>INV_SEL_4to7, INV_SEL_8toB=>INV_SEL_8toB,
                 INV_SEL_C=>INV_SEL_C, INV_SEL_F=>INV_SEL_F,
                 INV_WR=>INV_WR, INV_WRL=>INV_WRL, INV_WRLL=>INV_WRLL,
                 INV_WRLM=>INV_WRLM, INV_WRU=>INV_WRU,
                 INV_WRUM=>INV_WRUM, INV_WRUU=>INV_WRUU, PLDCLK=>PLDCLK,
                 R_W=>R_W, SIZ0=>SIZ0, SIZ1=>SIZ1, WAIT1=>WAIT1,
                 WAIT2=>WAIT2 );

-- *** Test Bench - User Defined Section ***
   TB : process
   begin
      wait; -- will wait forever
   end process;
-- *** End Test Bench - User Defined Section ***

end behavior;

